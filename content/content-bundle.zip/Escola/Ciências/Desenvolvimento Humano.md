#Ciências #SistemaEndócrino

Os seres humanos nascem, crescem, se desenvolvem, podem reproduzir, envelhecem e morrem. Assim, podemos classificar o desenvolvimento humano em quatro frases diferentes:
- Infância
	- Do nascimento ==até== aproximadamente ==10 anos de idade==;
	- ==Grande desenvolvimento==: falar, andar, brincar, crescimento mental e social;
	- Diferença: ==órgãos genitais==;
	- Corpo cresce e se desenvolve: crianças se tornam mais independentes.

- Adolescência
	- ==Mudanças físicas== (==hormônios da hipófise e hormônios sexuais==) (meninas × meninos);
	- Fase chamada puberdade;
	- Transformações emocionais, mudanças de humor;
	- Crescem aproximadamente 10cm por ano;
	- Mais apetite (alimentos fornecem energia).

- Fase adulta
	- ==Fase mais longa==;
	- Corpo ==completamente desenvolvido==;
	- ==Desenvolvimento mental e social continuam==;
	- Desenvolvimento profissional, independência financeira e formação de uma família (==opcional==).

- Velhice
	- ==Inicia-se aproximadamente aos 60 anos==;
	- Os idosos acumulam experiências ao longo da vida e podem compartilhá-la com os mais novos;
	- Com o passar dos anos, porém, o corpo sofre desgaste e as pessoas idosas podem apresentar diminuição da força muscular, enrugamento da pele, perda de cabelo, etc;
	- Atividades físicas, alimentação saudável e manter-se ativo, podem tornar o envelhecimento mais lento.