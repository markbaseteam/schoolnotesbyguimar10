#Ciências 

### O que é?

O sistema reprodutor é o sistema responsável para a geração de novos humanos. Para a geração de um novo ser é preciso dois sistemas distintos: Masculino e feminino.

### Gametas

- Gametas: células reprodutoras masculinas e femininas;
- Gametas masculinos: espermatozoides;
- Gametas femininos: Óvulos;
- Células produzidas no interior das gônadas - ovários e testículos.

Os gametas são as únicas células que possuem 23 cromossomos, somando 46 após a fecundação.

### ==Meio==se e mitose

Meiose: Divisão celular que reduz ao meio o número de cromossomos (23);
Mitose: Divisão celular que "produz" célula com 46 cromossomos.

### Reprodução
#### Existem dois tipos de reprodução:
- Sexuada: Precisa do gameta feminino + gameta masculino
- Assexuada: Presente em organismos mais simples

## Sistema genital masculino

Pênis: órgão com forma cilíndrica. A cabeça do pênis chama-se glande e, esta é coberta por uma pele chamada prepúcio;

Sêmen ou esperma: espermatozoides + líquidos, liberado durante um processo chamado ejaculação;

Ductos deferentes: têm a função de armazenar os espermatozoides e de transportá-los em direção à uretra;

Uretra: canal no interior do pênis, que conduz os espermatozoides e a urina para o meio externo (ejaculação);

Vesículas seminais: fabricam uma secreção que contribui para o movimento dos espermatozoides;

Próstata: produzir uma secreção fina e leitosa que contém nutrientes e também faz parte do sêmen.

## Sistema genital feminino

Ovários: produzem hormônios e ovócitos (ou óvulos) (gametas femininos) - Uma mulher libera durante a vida cerca de 400 óvulos - Após 45-50 anos de idade - menopausa;

Tubas uterinas: local onde ocorre a fecundação;

Após fecundação: zigoto sofre muitas divisões celulares e é encaminhado em direção ao útero;

Útero: órgão de paredes musculares. Durante a gravidez, o embrião fica alojado na parte interna do útero;

Vagina: canal que liga o útero ao meio externo.
### Ciclo menstrual

- ==1° dia menstruação = 1°dia do ciclo==;
- Período fértil: liberação do ovócito (óvulo);
- A cada 28-30 dias, o sistema genital feminino passa por modificações para uma preparação de uma possível gravidez;
- Caso não ocorra a gravidez, ocorre a menstruação;
- O ciclo dura cerca de 28-30 dias com a participação de 4 hormônios: Hipófise (fsh e lh) e ovários (estrógeno e progesterona).

## Fecundação
encontro do espermatozoide com o ovulo