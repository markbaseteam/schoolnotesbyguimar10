#Filosofia #Ética

- Existencialismo
- Diferença entre ética e moral - [[Tipos de Ética]]