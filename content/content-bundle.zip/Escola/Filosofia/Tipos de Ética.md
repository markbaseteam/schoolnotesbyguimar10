#Filosofia #Ética 

É importante lembrar que ética e moral NÃO SÃO SINÔNIMOS.

## Ética

==Análise crítica - estudo - sobre a moral==.

### Tipos de Ética
Diferentes formas de fazer uma análise sobre a moral.
#### Éticas ==deonto==lógicas
Análise a partir da regra - dever.
##### Características:
- Cumprimento do dever.
- Obediência às regras e normas.
- Cumpre as leis

Ex.: se uma pessoa atravessou a rua seguindo as normas e leis, esse é um comportamento deontológico.

#### Éticas ==teleo==lógicas
Análise da moral a partir de alguma finalidade.
**Etimologia**: teleos - objetivo

##### Características:
- Visa o objetivo;
- Cumpre uma finalidade;
- "Os fins justificam os meios"

### Análise ==bio==ética
Perspectiva relacionada a vida, sempre priorizando-a.
**Etimologia**: latim - bios - vida

## Moral

Comportamento relacionado aos costumes, hábitos e tradições de uma determinada cultura.

Para uma certa cultura, um comportamento pode ser considerado moral, enquanto para outra, não.

### Orientação Moral
#### Immanuel Kant (1724 - 1804)
- Elaborou o Imperativo Categórico

## Resumindo...

Ética - o que eu devo fazer
Moral - o que eu quero fazer

## O que determina o comportamento de uma pessoa?

Seus ==valores==. Para uma pessoa, a família pode ser mais importante, enquanto para outra pessoa, não. ==Depende de cada pessoa==.

## Axiologia

Ciência que estuda os valores.

Guilherme Marmiroli 8°B
Professor William Petelincar Pedro