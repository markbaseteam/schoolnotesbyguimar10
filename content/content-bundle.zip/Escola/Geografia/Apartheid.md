#Geografia #África 

O apartheid foi a política de segregação que ==vigorou na África do Sul entre os anos de 11948  e 1994, mas foi criado pelos ingleses ainda no período colonial==. Durante o Apartheid, ==direitos básicos como o voto e a livre circulação pelo país foram negados ao povo negro==.

A população negra lutou durante anos pelos seus direitos, sendo violentamente reprimida. O maior líder pelo direito dos negros na África do Sul, Nelson Mandela, passou 27 anos encarcerado por confrontar o sistema de Apartheid e se organizar politicamente para revertê-lo.