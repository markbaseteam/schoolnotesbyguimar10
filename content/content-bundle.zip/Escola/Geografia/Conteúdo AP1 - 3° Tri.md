#Geografia 

- [[África e suas regionalizações]];
- [[Crescimento vegetativo]] e densidade demográfica;
- [[Apartheid]].