#Geografia #Demografia 

### Como uma população cresce?
Chamamos de crescimento vegetativo a diferença entre a taxa de natalidade a taxa de mortalidade de um país, estado ou cidade. Vamos entender os dois conceitos.

### Taxa de natalidade
Refere-se ao número de nascimentos vivos a cada mil habitantes de um determinado local.

<img src="https://static.escolakids.uol.com.br/2019/04/calculo-taxa-natalidade.jpg" />
### Taxa de mortalidade
Refere-se ao número de óbitos para cada mil habitantes de um determinado local.

<img src="https://static.escolakids.uol.com.br/2019/04/calculo-taxa-mortalidade.jpg" />

### Calculando o crescimento vegetativo

<img src="https://static.escolakids.uol.com.br/2019/04/calculo-crescimento-vegetativo.jpg" />
