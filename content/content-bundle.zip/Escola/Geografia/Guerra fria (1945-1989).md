#Geografia #Geopolítica

A Guerra Fria e a designação de um período histórico de diisputas entre os Estados Unidos e União Soviética, compreendendo o período entre o final da [[Segunda guerra mundial (1939-1945)]] e a extinção da União Soviética em 1991.

### Contextos gerais 
- [[Segunda guerra mundial (1939-1945)]]


### O conflito entre os Estados Unidos e a União Soviética

![](https://youtu.be/MjHuK_2rSZY?si=cwwBCHuGLUMfZIhe)
