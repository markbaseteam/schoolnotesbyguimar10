#Geografia #Geopolítica

### Eixo do mal:
- Alemanha
- Itália
- Japão
- URSS

### Aliados
- Inglaterra
- França
- EUA => Entra na guerra em 1841
- URSS => "Saiu" do eixo do mal em 1841