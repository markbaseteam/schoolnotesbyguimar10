#Geografia #Demografia

## • Teoria Malthusiana
## • Teoria Neomalthusiana

