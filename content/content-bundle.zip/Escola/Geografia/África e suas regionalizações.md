#Geografia #África

Por sua história, etnias e religiões, a África pode ser dividida em duas grandes regiões:

- África do Norte (parte cinza) =>  Pode também ser chamada de África Setentrional ou África Mediterrânea.
- ==África Subsaariana== (parte laranja) => **Não pode** ser chamada de África do Sul

<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPEhuc8Pd6xNsmB4bw6wtK1HJSb0PwXvH3ig&usqp=CAU"  />

## Sahel
presença árabe, o islamismo é a religião dominante e a própria palavra Sahel deriva do idioma árabe  e significa "margem".

**É uma área de transição climática** entre as regiões mais úmidas e o deserto, que atravessa nações africanas distintas.

É uma região extremamente violenta e diversos terroristas vieram de lá.

## Regiões geográficas
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7FgypkvKBdo1IQqdFO9yqShWD_tFienUYfA&usqp=CAU" />

## Fatores e elementos climáticos
==Os fatores climáticos são as condições que determinam ou interferem nos elementos climáticos e os climas deles resultantes==. São ==eles que ajudam a explicar o porquê de uma região ser quente e úmida e outra ser fria e seca==, por exemplo.

> Os principais elementos climáticos são: **radiação**, **temperatura**, **pressão** e **umidade**.

## Vegetação do continente africano
Graças à precipitação, ==a vegetação predominante é a floresta tropical==. ==Ao norte e ao sul== dessa faixa, região de ==verões quentes e úmidos==, surgem as ==savanas==, que compõem o tipo de vegetação mais farta do continente.

## Relevo do continente africano
No continente africano ==prevalece a existência de planaltos de altitudes baixas e médias==. Nas regiões litorâneas, encontramos as planícies costeiras. As principais cadeias montanhosas que se destacam no continente africano são: Caddeia do Atlas (na região noroeste) e Cadeia do Cabo (na região sul).

## Desertos
O relevo do continente africano é marcado pela presença de dois grandes desertos: ==Saara== e o ==Deserto do Kalahari==. O primeiro encontra-se na região norte do país e o segundo se encontra mais ao sul. A ==maior parte da superfície da África é composta por planaltos com médias e elevadas altitudes==.