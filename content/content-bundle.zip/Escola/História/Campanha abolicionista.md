#História #Brasil 

# Iluminismo e a campanha abolicionista
