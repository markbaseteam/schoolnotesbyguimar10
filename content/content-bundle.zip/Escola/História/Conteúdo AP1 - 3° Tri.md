#História 

- [[Período Regencial]] 
- [[Segundo Reinado Brasileiro]]
- [[Campanha abolicionista]]