#História #Brasil 

Período provisório entre o primeiro e o [[Segundo Reinado Brasileiro]].
