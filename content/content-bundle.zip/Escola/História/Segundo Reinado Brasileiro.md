#História #Brasil

## Partidos
Os partidos "Conservadores" e "Restauradores" eram majoritariamente compostos por membros da elite agrária - "farinha do mesmo saco".
## Antecedentes
### • Cabanada (1832 - 1835)
Quem: camadas simples da população
Motivo: incompreensão das mudanças de regime - Pernambuco, Alagoas e Pará
### • Cabanagem (1835 - 1840)
Quem: indígenas, escravos e mestiços
Motivo: desentendimento na elite sobre a escolha do novo presidente da província - Belém
### • Revolução Farroupilha (1835 - 1845)
Quem: liberais, partidários do regime republicano e abolicionistas
Motivo: aumento dos impostos sobre o charque na província gaúcha - Rio Grande do Sul e sul de Santa Catarina
### • Sabinada (1837 - 1838) 
Quem: camadas simples da população
Motivo: fuga de autoridades - Bahia
### • Balaiada (1838 - 1841)
Quem: escravos e vaqueiros de grandes fazendas
Motivo: crise na produção algodoeira - Pernambuco, Alagoas e Pará
### • Golpe da maioridade
Promovido pelos políticos liberais;
Levou Pedro de Alcântara a se tornar governante aos 14 anos de idade.
## Acontecimentos
### • Revolução Liberal de 1842
- O que: 
### • [[Campanha abolicionista]]
No lugar da mão de obra escrava, mão de obra italiana imigrante.
- Inglaterra
	- Lei Aberdeen: Todo navio negreiro interceptado por um navio inglês terá os africanos devolvidos para a África e o comando do navio preso e levado para a Inglaterra.

- Brasil
	- Lei Eusébio de Queiroz
	- Ventre Livre

### • Sistema de parceria
Enganador. Fez muitos imigrantes virem para o Brasil em busca de oportunidades de trabalho. 

Fontes:
- Segundo Reinado - ATUALIZADO by Bruno Fucci on Prezi
https://prezi.com/sw9cu1fhlknv/segundo-reinado-atualizado/

- Professora Ivete Ortencio

