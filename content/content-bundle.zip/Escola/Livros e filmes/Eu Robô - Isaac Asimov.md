#Livro #Fiction

O livro "Eu robô", escrito por Isaac Asimov, foi publicado em 1950, mas não necessariamente foi escrito neste ano. Muitos contos do livro foram retirados dos contos de Asimov publicados nos jornais locais.

### Contexto histórico

Segunda Guerra Mundial:
- Medo da extinção da humanidade - Ficção científica influenciada por esse medo, trazendo temas como invasão alienígena e robótica.

### Definições importantes

- Cérebros positrônicos: nanocomputadores extremamente rápidos - IA - semelhantes aos algorítmos atuais - nanotecnologia.