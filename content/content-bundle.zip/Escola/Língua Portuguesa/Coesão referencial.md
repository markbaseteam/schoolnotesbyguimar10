#LínguaPortuguesa 
## Coesão textual
Técnica para tornar as partes do texto conectadas, evitando conexões desnecesárias.

## Anáfora
Processo pelo qual um termo recupera outro anterior a si, em geral, por meio de pronomes, numerais, artigos e advérbios.

## Catáfora
Remissão de um termo subsequente, em geral, por meio de pronomes demonstrativos ou indefinidos.