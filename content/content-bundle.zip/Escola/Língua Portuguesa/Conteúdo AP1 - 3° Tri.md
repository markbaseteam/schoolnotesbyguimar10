#LínguaPortuguesa 

- [[Narrativa de Ficção Científica]] - Subgêneros e Temas Recorrentes

- Contos "Robbie" e "Razão" - [[Livro Eu Robô]].

- As três leis da robótica de Isaac Asimov:
	- 1. ==Nenhum robô deve ferir um humano==, ou permitir, por negligência que um humano se machuque.
	- 2. ==Um robô sempre deve obedecer às ordens humanas==, exceto se as ordens forem contra a primeira lei.
	- 3. ==Os robôs devem preservar sua existência==, exceto se isso contrariar as duas primeiras leis.

- Características exclusivamente humanas:
	- Consciência
	- Afeto
	- Livre arbítrio

## Questões AP1
### Parte 1: Perguntas gerais sobre [[Narrativa de Ficção Científica]]
1. Pergunta objetiva - Literatura especulativa - 0,5
2. Pergunta objetiva - Ficção científica - 0,5
3. Pergunta objetiva - Objetivos da FC - 0,5
4. Pergunta objetiva - Entre as alternativas, escolha aquela que define de maneira correta um dos subgêneros da ficção científica. - 0,5
- Texto de jornal sobre alguns aspectos da tecnologia
5. Retire do texto... - 1
6. Se isso fosse uma narrativa de ficção científica seria de que subgênero? - 0,5

### Parte 2: Perguntas específicas sobre os contos Robbie e Razão do [[Livro Eu Robô]]
- Robbie
7. Conte sobre uma cena do conto "Robbie" - 
8. Dê sua opinião sobre um aspecto da inteligência artificial de Robbie. - Argumente - 1,5
9. Pergunta sobre o conto Robbie.
- Razão
10. Pergunta sobre o conto "Razão" - Argumente sobre um aspecto do pensamento do cutie - 
11. Trecho do conto "Razão" - diálogo - Explique sobre o comportamento do cutie ao longo do conto - 
12. Parece a 11 - Como cutie se comportou? - Resumo das ações do cutie ao longo do conto - 


> "Quem tiver talento, obterá o êxito na medida que lhe corresponda. Porém, apenas se persistir naquilo que faz. Nunca deixe o seu sentido moral impedi-lo de fazer o que está certo."
> - Isaac Asimov