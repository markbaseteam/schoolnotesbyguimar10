#LínguaPortuguesa 

## Introdução

A Ficção Científica (também conhecida como Sci-fi ou FC) ==é um subgênero das narrativas de ficção==. Junto com as narrativas de Terror e de Fantasia, é ==definida como Literatura Especulativa, um gênero narrativo que "inventa" um mundo próprio==.

O que define a FC é ==incluir componentes científicos como essenciais para o entendimento e andamento da trama ficcional==.

## Origens da Narrativa de Ficção Científica

O crítico literário Adam Roberts argumenta que a Ficção Científica teve seu início por volta de 1600 com a obra Somnium, do astrônomo Johannes Kepler.

No geral, no entanto, os críticos costumam datar o início da FC com a publicação de ==Frankeinstein, de Mary Shelley==, em 1818.

Depois, o fim do século XIX conhecerá aqueles autores que são considerados os grandes divulgadores e mestres da ficção científica: Júlio Verne e H. G. Wells.